<?php
  $hostname = "localhost";
  $dbuser = "root";
  $password = "";
  $dbname = "schooldb";
  
  $conn = mysqli_connect($hostname,$dbuser,$password,$dbname) or die('error');

?>