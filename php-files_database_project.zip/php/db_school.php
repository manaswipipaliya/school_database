<html ng-app="stuform">
   <head>
       <title>
	      school
	   </title>
	   <style>
	   form {
          max-width: 750px;
          margin: 10px auto;
          padding: 10px 20px;
          background: #f4f7f8;
          border-radius: 16px;
            }

	   div.alignment {
           text-align: center;
             }
	    body{
             background: #a3c2c2;
             margin: 0 auto;
             font-family: arial;
            }
			 heading
			     {
             color: brown;
             font-size: 14px;
                 }
		     h1
			 {color: white;}
		#container{


             padding: 10px;
             width: 50%;
             margin: 1 auto;
             margin-top: 1%;
             margin-bottom: 1%;
             background-color: #334d4d;
                  }
		 .sampleBtn
		      {button {
              padding: 19px 39px 18px 39px;
              color: #FFF;
              background-color: #4bc970;
              font-size: 16px;
              text-align: center;
              font-style: normal;
              border-radius: 5px;
              width: 100%;
              border: 1px solid #3ac162;
              border-width: 1px 1px 3px;
              box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
              margin-bottom: 10px;
                       }

               background-color: #f1f1f1;
                }
				
         .sampleBtn:hover
		     {
             color: white;
             background-color: brown;
             cursor: pointer;
             }
		  .user:hover
		      {
             padding-top: 7px;
             padding-bottom: 7px;
             padding-left: 5px;
             padding-right: 5px;
             margin-bottom: 30px;
			 background-color:#a3c2c2;
	         color:#fff2e6;
	         input{color:#fff2e6;}
              }
		  p.outset {border-style: outset;}
		</style>
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
		<script>
		    
             function validateForm()
			 {
			 var letters = /^[A-Za-z]+$/;
             var x = document.forms["register"]["sname"].value;
             if ((x == "") || !isNaN(x) || !(letters.test(x)) ) {
             alert("School name must be filled out or the name must have only letters");
             return false;
                          }
			
		     if(letters.test(word))
                          {
                       return true;
                          }
                         else
                          {
                        alert("name must have only letters");
                       return false;
                          }
						 
             }
        </script>
		
   </head>
   <body ng-controller="stud_control">
    <div class="alignment">
      <div id="container">
      <h1 align="center">School Form</h1></div>
	  <p class="outset">
	  <form name="register" action="" onsubmit="return validateForm()" method="post">
	    <div ng-app="stuform" ng-controller="stud_control">
	    <div class="user">
	    <heading>SCHOOL ID:<sup>*</sup>:</heading>
	    <input name="s_id" type="number" min="00001" max="99999" maxlength="5" required></input><br><br>
	    </div>
		<div class="user">
	  	<heading>Type your school name here:<sup>*</sup>:</heading>
	  	<input name="sname" ng-model="s_name" maxlength="25" required></input><br><br></div>
		<heading>SCHOOL NAME:</heading>
		  <input name="s_name" value="{{s_name | uppercase}} ">
		</div>
		<br>
		<div ng-app="stuform" ng-controller="stud_control">
	    <div class="user">
	  	<heading>Type your address here:</heading>
	  	<input type="text" ng-model="address" name="addres" maxlength="40">
	  	</input><br><br>
	    </div>
		<div class="user">
	  	<heading>ADDRESS:</heading>
	  	<input name="address" value="{{address | uppercase}}">
	  	</input><br><br>
	    </div>
		</div>
		<div style="text-align:center">
	    <input name="submit1" type="submit" class="sampleBtn"/>
	   <input type="reset" class="sampleBtn" />
  	    </div>
	  </form></p>
	  </div>
	  <?php
	    include ('connection.php');
		
		if(isset($_POST['submit1']))
		{
			$s_id = $_POST['s_id'];
			$s_name = $_POST['s_name'];
			$address = $_POST['address'];
			
			$q = "INSERT INTO school VALUES('$s_id','$s_name','$address')";
			$conn->query($q) or die('ERROR!!');
			
		}
	  
	  
	  ?>
	  
	  <script>
        var app = angular.module('stuform', []);
        app.controller('stud_control', function($scope) {
        });
</script>

   </body>
</html>